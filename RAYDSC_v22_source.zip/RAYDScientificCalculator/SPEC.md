# SPEC-22-RAYD-Dark-Black-White-Display

## Background

The user wanted the visible `OK` label removed and requested a white display with a dark black calculator body.

## Requirements

- Must remove the visible OK label from the replay pad.
- Must make the display panel white.
- Must make the calculator body/panel/key style dark black.
- Must keep the LOG download and V21 template fixes.
- Must keep evaluation available through the `=` key.

## Method

- Update Compose color constants.
- Keep center replay button functional but blank, matching a physical replay pad without an OK label.
- Replace completed evaluation status with `DEL locked` instead of `OK: DEL locked`.

## Implementation

- Updated `MainActivity.kt`.
- Updated `themes.xml`.
- Updated app version to 22.0.0.

## Milestones

1. Build APK.
2. Open app and verify no OK label is visible.
3. Verify display is white.
4. Verify calculator body is dark black.
5. Verify LOG button still exports a non-empty bug file.

## Gathering Results

Visual inspection should confirm a white display and black calculator body. Bug reports should continue using the LOG button.

# SPEC-21-RAYD-Template-Delete-and-Power-Fix

## Background

The V20 bug log successfully uploaded and showed two major issues: natural templates could be corrupted by DEL, and `xʸ` after `=` started a blank malformed power instead of continuing from `Ans`.

## Requirements

- Must keep the LOG export working.
- Must prevent DEL/backspace from exposing hidden raw template names.
- Must protect integral/power/log/root templates from structural comma/parenthesis corruption.
- Must make `xʸ` wrap the previous value as the base.
- Must make `xʸ` after a completed result continue from `Ans`.

## Method

- Add generic template delete protection for non-fraction templates.
- Add `insertPowerTemplate()` similar to reciprocal behavior.
- Keep hidden raw representation valid while the visual Natural Display shows textbook-style templates.

## Implementation

- Updated `MainActivity.kt`.
- Updated app version to 21.0.0.

## Milestones

1. Build debug APK.
2. Test `888 × ∫dx DEL`.
3. Test `88 × 99 = xʸ 9 9`.
4. Test `pow`/power template DEL near the end.
5. Export LOG and upload it if another bug appears.

## Gathering Results

The exported bug log should show template removal/editing without raw partial tokens such as `integr`, `integ`, or missing closing `)`.
