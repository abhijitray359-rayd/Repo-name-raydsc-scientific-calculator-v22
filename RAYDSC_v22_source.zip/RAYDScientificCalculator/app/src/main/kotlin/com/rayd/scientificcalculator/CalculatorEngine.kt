package com.rayd.scientificcalculator

import kotlin.math.*

enum class AngleMode {
    DEG, RAD, GRAD
}

enum class DisplayMode {
    DECIMAL, FRACTION, ENGINEERING, SCIENTIFIC
}

class CalculatorException(message: String) : RuntimeException(message)

object CalculatorEngine {
    private val defaultVariables = mapOf(
        "A" to 0.0, "B" to 0.0, "C" to 0.0, "D" to 0.0,
        "E" to 0.0, "F" to 0.0, "X" to 0.0, "Y" to 0.0, "M" to 0.0
    )

    fun evaluate(
        expression: String,
        angleMode: AngleMode,
        ans: Double,
        variables: Map<String, Double> = defaultVariables
    ): Double {
        val normalized = normalize(expression)
        if (normalized.isBlank()) return 0.0
        val parser = Parser(normalized, angleMode, ans, defaultVariables + variables.mapKeys { it.key.uppercase() })
        val value = parser.parseExpression()
        parser.ensureFullyConsumed()
        if (!value.isFinite()) throw CalculatorException("Math error")
        return normalizeZero(value)
    }

    fun normalize(expression: String): String {
        return expression
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace("π", "pi")
            .replace("√", "sqrt")
            .replace("³sqrt", "cbrt")
            .replace("³√", "cbrt")
            .replace(" ", "")
    }

    fun format(value: Double, mode: DisplayMode = DisplayMode.DECIMAL, engineeringShift: Int = 0): String {
        val v = normalizeZero(value)
        if (v.isNaN() || v.isInfinite()) return "Math error"
        return when (mode) {
            DisplayMode.FRACTION -> toFraction(v)
            DisplayMode.ENGINEERING -> formatEngineering(v, engineeringShift)
            DisplayMode.SCIENTIFIC -> formatScientific(v)
            DisplayMode.DECIMAL -> formatDecimal(v)
        }
    }

    fun formatDecimal(value: Double): String {
        val v = normalizeZero(value)
        if (abs(v - round(v)) < 1e-10 && abs(v) < 1e15) return round(v).toLong().toString()
        val absV = abs(v)
        val text = if ((absV >= 1e12 || absV < 1e-8) && absV != 0.0) {
            "%.10E".format(v)
        } else {
            "%.12f".format(v)
        }
        return clean(text)
    }

    private fun formatScientific(value: Double): String {
        val v = normalizeZero(value)
        if (v == 0.0) return "0"
        val exponent = floor(log10(abs(v))).toInt()
        val mantissa = v / 10.0.pow(exponent)
        return "${clean("%.10f".format(mantissa))}×10${toSuperscript(exponent)}"
    }

    private fun formatEngineering(value: Double, engineeringShift: Int = 0): String {
        val v = normalizeZero(value)
        if (v == 0.0) return "0×10⁰"
        val baseExponent = floor(log10(abs(v)) / 3.0).toInt() * 3
        val exponent = baseExponent + (engineeringShift * 3)
        val mantissa = v / 10.0.pow(exponent)
        return "${clean("%.10f".format(mantissa))}×10${toSuperscript(exponent)}"
    }

    private fun toSuperscript(value: Int): String {
        return value.toString().map { char ->
            when (char) {
                '-' -> '⁻'
                '0' -> '⁰'
                '1' -> '¹'
                '2' -> '²'
                '3' -> '³'
                '4' -> '⁴'
                '5' -> '⁵'
                '6' -> '⁶'
                '7' -> '⁷'
                '8' -> '⁸'
                '9' -> '⁹'
                else -> char
            }
        }.joinToString("")
    }

    private fun toFraction(value: Double): String {
        val v = normalizeZero(value)
        if (abs(v - round(v)) < 1e-10) return round(v).toLong().toString()
        if (abs(v) > 1e8) return formatDecimal(v)

        val sign = if (v < 0) -1 else 1
        var x = abs(v)
        var a = floor(x).toLong()
        var h1 = 1L
        var k1 = 0L
        var h = a
        var k = 1L
        var iter = 0

        while (abs(x - a) > 1e-12 && k < 100000 && iter < 32) {
            x = 1.0 / (x - a)
            a = floor(x).toLong()
            val h2 = h1
            val k2 = k1
            h1 = h
            k1 = k
            h = a * h1 + h2
            k = a * k1 + k2
            iter++
        }

        val numerator = h * sign
        return if (k == 1L) numerator.toString() else "$numerator/$k"
    }

    private fun clean(text: String): String {
        return text
            .replace(Regex("0+(?=E)"), "")
            .replace(Regex("\\.(?=E)"), "")
            .replace(Regex("0+$"), "")
            .replace(Regex("\\.$"), "")
            .replace("E+", "E")
    }

    private fun normalizeZero(value: Double): Double {
        return if (abs(value) < 1e-12) 0.0 else value
    }
}

private class Parser(
    private val input: String,
    private val angleMode: AngleMode,
    private val ans: Double,
    private val variables: Map<String, Double>
) {
    private var pos: Int = 0

    fun parseExpression(): Double {
        var value = parseTerm()
        while (true) {
            value = when {
                match('+') -> value + parseTerm()
                match('-') -> value - parseTerm()
                else -> return value
            }
        }
    }

    private fun parseTerm(): Double {
        var value = parsePower()
        while (true) {
            value = when {
                match('*') -> value * parsePower()
                match('/') -> {
                    val divisor = parsePower()
                    if (abs(divisor) < 1e-15) throw CalculatorException("Cannot divide by zero")
                    value / divisor
                }
                else -> return value
            }
        }
    }

    private fun parsePower(): Double {
        val base = parseUnary()
        return if (match('^')) {
            val exponent = parsePower()
            base.pow(exponent)
        } else {
            base
        }
    }

    private fun parseUnary(): Double {
        return when {
            match('+') -> parseUnary()
            match('-') -> -parseUnary()
            else -> parsePostfix()
        }
    }

    private fun parsePostfix(): Double {
        var value = parsePrimary()
        while (true) {
            value = when {
                match('!') -> factorial(value)
                match('%') -> value / 100.0
                else -> return value
            }
        }
    }

    private fun parsePrimary(): Double {
        skipSpaces()

        if (match('(')) {
            val value = parseExpression()
            expect(')')
            return value
        }

        if (peek()?.isDigit() == true || peek() == '.') {
            return parseNumber()
        }

        if (peek()?.isLetter() == true) {
            val name = parseName()
            val lower = name.lowercase()
            val upper = name.uppercase()

            return when {
                lower == "pi" -> Math.PI
                name == "e" -> Math.E
                lower == "ans" -> ans
                upper.length == 1 && variables.containsKey(upper) -> variables[upper] ?: 0.0
                lower in setOf("integral", "int", "deriv", "d", "sum", "prod") -> parseSpecialRaw(lower)
                else -> parseFunction(lower)
            }
        }

        throw CalculatorException("Invalid expression")
    }

    private fun parseFunction(name: String): Double {
        val args = parseArguments()
        fun one(op: (Double) -> Double): Double {
            if (args.size != 1) throw CalculatorException("$name needs 1 value")
            return op(args[0])
        }

        fun two(op: (Double, Double) -> Double): Double {
            if (args.size != 2) throw CalculatorException("$name needs 2 values")
            return op(args[0], args[1])
        }

        return when (name) {
            "sqrt" -> one { x ->
                if (x < 0) throw CalculatorException("Math error")
                sqrt(x)
            }
            "frac" -> two { numerator, denominator ->
                if (abs(denominator) < 1e-15) throw CalculatorException("Cannot divide by zero")
                numerator / denominator
            }
            "pow" -> two { base, exponent -> base.pow(exponent) }
            "cbrt" -> one { x -> sign(x) * abs(x).pow(1.0 / 3.0) }
            "root" -> two { n, x -> nthRoot(n, x) }
            "inv" -> one { x ->
                if (abs(x) < 1e-15) throw CalculatorException("Cannot divide by zero")
                1.0 / x
            }
            "sin" -> one { x -> sin(toRadiansIfNeeded(x)) }
            "cos" -> one { x -> cos(toRadiansIfNeeded(x)) }
            "tan" -> one { x -> tan(toRadiansIfNeeded(x)) }
            "asin" -> one { x ->
                if (x < -1.0 || x > 1.0) throw CalculatorException("Math error")
                fromRadiansIfNeeded(asin(x))
            }
            "acos" -> one { x ->
                if (x < -1.0 || x > 1.0) throw CalculatorException("Math error")
                fromRadiansIfNeeded(acos(x))
            }
            "atan" -> one { x -> fromRadiansIfNeeded(atan(x)) }
            "sinh" -> one { x -> sinh(x) }
            "cosh" -> one { x -> cosh(x) }
            "tanh" -> one { x -> tanh(x) }
            "asinh" -> one { x -> ln(x + sqrt(x * x + 1.0)) }
            "acosh" -> one { x ->
                if (x < 1.0) throw CalculatorException("Math error")
                ln(x + sqrt(x - 1.0) * sqrt(x + 1.0))
            }
            "atanh" -> one { x ->
                if (abs(x) >= 1.0) throw CalculatorException("Math error")
                0.5 * ln((1.0 + x) / (1.0 - x))
            }
            "log" -> one { x ->
                if (x <= 0) throw CalculatorException("Math error")
                log10(x)
            }
            "ln" -> one { x ->
                if (x <= 0) throw CalculatorException("Math error")
                ln(x)
            }
            "logbase" -> two { base, x ->
                if (base <= 0 || base == 1.0 || x <= 0) throw CalculatorException("Math error")
                ln(x) / ln(base)
            }
            "exp" -> one { x -> exp(x) }
            "pow10" -> one { x -> 10.0.pow(x) }
            "abs" -> one { x -> abs(x) }
            "round" -> one { x -> round(x) }
            "floor" -> one { x -> floor(x) }
            "ceil" -> one { x -> ceil(x) }
            "npr" -> two { n, r -> permutation(n, r) }
            "ncr" -> two { n, r -> combination(n, r) }
            "rand" -> {
                if (args.isNotEmpty()) throw CalculatorException("rand needs no values")
                Math.random()
            }
            "ranint", "randint" -> two { a, b ->
                val start = round(a).toInt()
                val end = round(b).toInt()
                if (end < start) throw CalculatorException("Invalid range")
                (start..end).random().toDouble()
            }
            "gcd" -> two { a, b -> gcd(round(a).toLong(), round(b).toLong()).toDouble() }
            "lcm" -> two { a, b ->
                val ga = gcd(round(a).toLong(), round(b).toLong())
                abs(round(a).toLong() / ga * round(b).toLong()).toDouble()
            }
            "count" -> {
                if (args.isEmpty()) throw CalculatorException("count needs values")
                args.size.toDouble()
            }
            "mean" -> {
                if (args.isEmpty()) throw CalculatorException("mean needs values")
                args.average()
            }
            "sumx" -> {
                if (args.isEmpty()) throw CalculatorException("sumx needs values")
                args.sum()
            }
            "sumx2" -> {
                if (args.isEmpty()) throw CalculatorException("sumx2 needs values")
                args.sumOf { it * it }
            }
            "sigmax" -> {
                if (args.isEmpty()) throw CalculatorException("σx needs values")
                val mean = args.average()
                sqrt(args.sumOf { (it - mean) * (it - mean) } / args.size)
            }
            "sx" -> {
                if (args.size < 2) throw CalculatorException("sx needs 2+ values")
                val mean = args.average()
                sqrt(args.sumOf { (it - mean) * (it - mean) } / (args.size - 1))
            }
            "minx" -> {
                if (args.isEmpty()) throw CalculatorException("minx needs values")
                args.minOrNull() ?: throw CalculatorException("minx needs values")
            }
            "maxx" -> {
                if (args.isEmpty()) throw CalculatorException("maxx needs values")
                args.maxOrNull() ?: throw CalculatorException("maxx needs values")
            }
            "polr" -> two { x, y -> sqrt(x * x + y * y) }
            "poltheta" -> two { x, y -> fromRadiansIfNeeded(atan2(y, x)) }
            "recx" -> two { r, theta -> r * cos(toRadiansIfNeeded(theta)) }
            "recy" -> two { r, theta -> r * sin(toRadiansIfNeeded(theta)) }
            "deg" -> one { x -> Math.toDegrees(x) }
            "rad" -> one { x -> Math.toRadians(x) }
            "dms" -> one { x -> decimalToDmsNumber(x) }
            else -> throw CalculatorException("Unknown: $name")
        }
    }

    private fun parseSpecialRaw(name: String): Double {
        val args = readArgumentStrings()
        return when (name) {
            "integral", "int" -> {
                if (args.size != 3) throw CalculatorException("integral(expr,a,b)")
                val a = eval(args[1])
                val b = eval(args[2])
                integrate(args[0], a, b)
            }
            "deriv", "d" -> {
                if (args.size != 2) throw CalculatorException("deriv(expr,x)")
                val x = eval(args[1])
                derivative(args[0], x)
            }
            "sum" -> {
                if (args.size != 3) throw CalculatorException("sum(expr,start,end)")
                val start = round(eval(args[1])).toInt()
                val end = round(eval(args[2])).toInt()
                if (end < start) throw CalculatorException("Invalid range")
                if (end - start > 10000) throw CalculatorException("Range too large")
                var total = 0.0
                for (i in start..end) total += evalWithX(args[0], i.toDouble())
                total
            }
            "prod" -> {
                if (args.size != 3) throw CalculatorException("prod(expr,start,end)")
                val start = round(eval(args[1])).toInt()
                val end = round(eval(args[2])).toInt()
                if (end < start) throw CalculatorException("Invalid range")
                if (end - start > 10000) throw CalculatorException("Range too large")
                var total = 1.0
                for (i in start..end) total *= evalWithX(args[0], i.toDouble())
                total
            }
            else -> throw CalculatorException("Unknown: $name")
        }
    }

    private fun integrate(expression: String, a: Double, b: Double): Double {
        if (a == b) return 0.0
        val n = 1000
        val h = (b - a) / n
        var sum = evalWithX(expression, a) + evalWithX(expression, b)
        for (i in 1 until n) {
            val x = a + i * h
            sum += if (i % 2 == 0) 2.0 * evalWithX(expression, x) else 4.0 * evalWithX(expression, x)
        }
        return sum * h / 3.0
    }

    private fun derivative(expression: String, x: Double): Double {
        val h = 1e-5 * max(1.0, abs(x))
        return (evalWithX(expression, x + h) - evalWithX(expression, x - h)) / (2.0 * h)
    }

    private fun eval(expression: String): Double {
        return CalculatorEngine.evaluate(expression, angleMode, ans, variables)
    }

    private fun evalWithX(expression: String, xValue: Double): Double {
        val scoped = variables + mapOf("X" to xValue)
        return CalculatorEngine.evaluate(expression, angleMode, ans, scoped)
    }

    private fun parseArguments(): List<Double> {
        expect('(')
        val args = mutableListOf<Double>()
        if (match(')')) return args
        while (true) {
            args.add(parseExpression())
            if (match(',')) continue
            expect(')')
            return args
        }
    }

    private fun readArgumentStrings(): List<String> {
        skipSpaces()
        if (peek() != '(') throw CalculatorException("Missing (")
        pos++
        val args = mutableListOf<String>()
        var depth = 0
        var start = pos
        while (pos < input.length) {
            when (input[pos]) {
                '(' -> {
                    depth++
                    pos++
                }
                ')' -> {
                    if (depth == 0) {
                        args.add(input.substring(start, pos))
                        pos++
                        return args.map { it.trim() }.filter { it.isNotEmpty() }
                    }
                    depth--
                    pos++
                }
                ',' -> {
                    if (depth == 0) {
                        args.add(input.substring(start, pos))
                        pos++
                        start = pos
                    } else {
                        pos++
                    }
                }
                else -> pos++
            }
        }
        throw CalculatorException("Missing )")
    }

    private fun parseNumber(): Double {
        val start = pos
        while (peek()?.isDigit() == true || peek() == '.') pos++
        if (peek() == 'E') {
            pos++
            if (peek() == '+' || peek() == '-') pos++
            while (peek()?.isDigit() == true) pos++
        }
        return input.substring(start, pos).toDoubleOrNull()
            ?: throw CalculatorException("Invalid number")
    }

    private fun parseName(): String {
        val start = pos
        while (peek()?.isLetterOrDigit() == true) pos++
        return input.substring(start, pos)
    }

    private fun factorial(value: Double): Double {
        val n = integer(value, "Factorial")
        if (n > 170) throw CalculatorException("Too large")
        var result = 1.0
        for (i in 2..n) result *= i
        return result
    }

    private fun permutation(nValue: Double, rValue: Double): Double {
        val n = integer(nValue, "nPr")
        val r = integer(rValue, "nPr")
        if (r < 0 || n < 0 || r > n) throw CalculatorException("Math error")
        var result = 1.0
        for (i in 0 until r) result *= (n - i)
        return result
    }

    private fun combination(nValue: Double, rValue: Double): Double {
        val n = integer(nValue, "nCr")
        val r = integer(rValue, "nCr")
        if (r < 0 || n < 0 || r > n) throw CalculatorException("Math error")
        val k = min(r, n - r)
        var result = 1.0
        for (i in 1..k) result = result * (n - k + i) / i
        return result
    }

    private fun integer(value: Double, name: String): Int {
        if (value < 0 || abs(value - round(value)) > 1e-10) {
            throw CalculatorException("$name needs whole number")
        }
        return round(value).toInt()
    }

    private fun nthRoot(nValue: Double, x: Double): Double {
        val n = integer(nValue, "Root")
        if (n == 0) throw CalculatorException("Math error")
        if (x < 0 && n % 2 == 0) throw CalculatorException("Math error")
        return if (x < 0) -abs(x).pow(1.0 / n) else x.pow(1.0 / n)
    }

    private fun decimalToDmsNumber(value: Double): Double {
        val sign = if (value < 0) -1.0 else 1.0
        val absValue = abs(value)
        val degrees = floor(absValue)
        val minutesFull = (absValue - degrees) * 60.0
        val minutes = floor(minutesFull)
        val seconds = (minutesFull - minutes) * 60.0
        return sign * (degrees + minutes / 100.0 + seconds / 10000.0)
    }

    private fun gcd(aValue: Long, bValue: Long): Long {
        var a = abs(aValue)
        var b = abs(bValue)
        while (b != 0L) {
            val t = a % b
            a = b
            b = t
        }
        return if (a == 0L) 1L else a
    }

    private fun toRadiansIfNeeded(x: Double): Double {
        return when (angleMode) {
            AngleMode.DEG -> Math.toRadians(x)
            AngleMode.GRAD -> x * Math.PI / 200.0
            AngleMode.RAD -> x
        }
    }

    private fun fromRadiansIfNeeded(x: Double): Double {
        return when (angleMode) {
            AngleMode.DEG -> Math.toDegrees(x)
            AngleMode.GRAD -> x * 200.0 / Math.PI
            AngleMode.RAD -> x
        }
    }

    fun ensureFullyConsumed() {
        skipSpaces()
        if (pos != input.length) throw CalculatorException("Invalid expression")
    }

    private fun expect(c: Char) {
        if (!match(c)) throw CalculatorException("Missing $c")
    }

    private fun match(c: Char): Boolean {
        skipSpaces()
        return if (peek() == c) {
            pos++
            true
        } else false
    }

    private fun peek(): Char? = input.getOrNull(pos)

    private fun skipSpaces() {
        while (peek()?.isWhitespace() == true) pos++
    }
}
