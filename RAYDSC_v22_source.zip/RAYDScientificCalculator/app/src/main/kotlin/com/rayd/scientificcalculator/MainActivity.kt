package com.rayd.scientificcalculator

import android.content.Context
import android.os.Bundle
import android.graphics.drawable.ColorDrawable
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat
import androidx.compose.ui.platform.LocalContext
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Body = Color(0xFF000000)
private val Panel = Color(0xFF050505)
private val Display = Color(0xFFFFFFFF)
private val DisplayText = Color(0xFF000000)
private val FunctionKey = Color(0xFF080808)
private val NumberKey = Color(0xFF111111)
private val NumberText = Color.White
private val ActionKey = Color(0xFF65B82E)
private val DeleteKey = Color(0xFF5EA12C)
private val EqualKey = Color(0xFF2F8E54)
private val ShiftText = Color(0xFFE7B64C)
private val AlphaText = Color(0xFFE0709C)
private val SecondaryText = Color(0xFF9AD7FF)
private val RaydColorScheme = darkColorScheme(background = Body, surface = Body, primary = EqualKey, secondary = ActionKey)
private const val CursorMark = "│"

private enum class PendingAction {
    NONE, STORE, RECALL
}

private enum class CalcMode(val display: String, val hint: String) {
    COMP("COMP", "Normal calculations"),
    CMPLX("CMPLX", "Complex numbers preview"),
    STAT("STAT", "Statistics editor preview"),
    BASE_N("BASE-N", "Binary / octal / hex preview"),
    EQN("EQN", "Equation solver preview"),
    MATRIX("MATRIX", "Matrix editor preview"),
    TABLE("TABLE", "Function table preview"),
    VECTOR("VECTOR", "Vector editor preview")
}

private enum class ActiveMenu {
    NONE, MODE, SETUP
}

private data class TemplateCursorBounds(
    val functionStart: Int,
    val argsStart: Int,
    val argumentStarts: List<Int>,
    val end: Int,
    val functionName: String
)

private data class CalcKey(
    val primary: String,
    val shift: String? = null,
    val alpha: String? = null
)

private val keypadRows = listOf(
    listOf(
        CalcKey("SHIFT"),
        CalcKey("ALPHA"),
        CalcKey("MODE", "SETUP"),
        CalcKey("ON", "OFF")
    ),
    listOf(
        CalcKey("CALC", "SOLVE"),
        CalcKey("∫dx", "d/dx"),
        CalcKey("x⁻¹", "x!"),
        CalcKey("log□", "Σ")
    ),
    listOf(
        CalcKey("a/b", "d/c"),
        CalcKey("√", "³√"),
        CalcKey("x²", "x³"),
        CalcKey("xʸ", "ʸ√x"),
        CalcKey("log", "10ˣ"),
        CalcKey("ln", "eˣ")
    ),
    listOf(
        CalcKey("(-)", "Abs", "A"),
        CalcKey("°′″", "Rnd", "B"),
        CalcKey("hyp", null, "C"),
        CalcKey("sin", "sin⁻¹", "D"),
        CalcKey("cos", "cos⁻¹", "E"),
        CalcKey("tan", "tan⁻¹", "F")
    ),
    listOf(
        CalcKey("RCL", "STO"),
        CalcKey("ENG", "←"),
        CalcKey("(", "%"),
        CalcKey(")", ",", "Y"),
        CalcKey("S⇔D", "a⇔b", "X"),
        CalcKey("M+", "M-", "M")
    ),
    listOf(
        CalcKey("7", "CONST"),
        CalcKey("8", "CONV"),
        CalcKey("9", "CLR"),
        CalcKey("DEL", "INS"),
        CalcKey("AC", "OFF")
    ),
    listOf(
        CalcKey("4", "MATRIX"),
        CalcKey("5", "VECTOR"),
        CalcKey("6"),
        CalcKey("×", "nPr"),
        CalcKey("÷", "nCr")
    ),
    listOf(
        CalcKey("1", "STAT"),
        CalcKey("2", "CMPLX"),
        CalcKey("3", "BASE"),
        CalcKey("+", "Pol"),
        CalcKey("-", "Rec")
    ),
    listOf(
        CalcKey("0", "Rnd"),
        CalcKey(".", "Ran#"),
        CalcKey("EXP", "RanInt", "π"),
        CalcKey("Ans", "DRG", "e"),
        CalcKey("=")
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Match the Activity window to the app body color before Compose draws.
        // This removes the slow-looking blank/white launch flash on many phones.
        window.setBackgroundDrawable(ColorDrawable(android.graphics.Color.rgb(16, 19, 25)))
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = RaydColorScheme) {
                RaydCalculatorApp()
            }
        }
    }
}

@Composable
fun RaydCalculatorApp() {
    var expression by remember { mutableStateOf("") }
    var cursor by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf("0") }
    var ans by remember { mutableStateOf(0.0) }
    var angleMode by remember { mutableStateOf(AngleMode.DEG) }
    var displayMode by remember { mutableStateOf(DisplayMode.DECIMAL) }
    var calcMode by remember { mutableStateOf(CalcMode.COMP) }
    var activeMenu by remember { mutableStateOf(ActiveMenu.NONE) }
    var engineeringShift by remember { mutableIntStateOf(0) }
    var shift by remember { mutableStateOf(false) }
    var alpha by remember { mutableStateOf(false) }
    var hyp by remember { mutableStateOf(false) }
    var pendingAction by remember { mutableStateOf(PendingAction.NONE) }
    var status by remember { mutableStateOf("Ready") }
    var history by remember { mutableStateOf(listOf<String>()) }
    var historyRaw by remember { mutableStateOf(listOf<String>()) }
    var historyIndex by remember { mutableIntStateOf(-1) }
    var lastEvaluatedRaw by remember { mutableStateOf<String?>(null) }
    var justEvaluated by remember { mutableStateOf(false) }
    var variables by remember { mutableStateOf(defaultVariables()) }

    val context = LocalContext.current
    val logFileName = "rayd_action_memory_log.txt"
    var logLines by remember { mutableStateOf(listOf<String>()) }

    fun logTimestamp(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
    }

    fun snapshot(): String {
        return "expr=\"${pretty(expression)}\" raw=\"$expression\" cursor=$cursor result=\"$result\" status=\"$status\" mode=${calcMode.display} angle=${angleMode.name} display=${displayMode.name} shift=$shift alpha=$alpha hyp=$hyp ans=${CalculatorEngine.format(ans)}"
    }

    fun appendLog(action: String, before: String, after: String) {
        val entry = "${logTimestamp()}\nACTION: $action\nBEFORE: $before\nAFTER:  $after\n"
        logLines = (logLines + entry).takeLast(1000)

        // Persistent memory log: saves every action immediately so LOG download
        // still works after recomposition/backgrounding and does not create an empty file.
        try {
            context.openFileOutput(logFileName, Context.MODE_APPEND).bufferedWriter().use { writer ->
                writer.write(entry)
                writer.newLine()
            }
        } catch (_: Exception) {
            // Keep the calculator usable even if internal logging fails.
        }
    }

    fun runLogged(action: String, block: () -> Unit) {
        val before = snapshot()
        try {
            block()
        } finally {
            appendLog(action, before, snapshot())
        }
    }

    fun buildLogText(): String {
        val header = buildString {
            appendLine("RAYDSC Bug Log")
            appendLine("Version: 22.0.0")
            appendLine("Generated: ${logTimestamp()}")
            appendLine("Latest state: ${snapshot()}")
            appendLine("------------------------------------------------------------")
        }

        val savedLog = try {
            context.openFileInput(logFileName).bufferedReader().use { reader ->
                reader.readText()
            }
        } catch (_: Exception) {
            ""
        }

        val liveLog = logLines.joinToString(separator = "\n")
        val body = when {
            savedLog.isNotBlank() -> savedLog
            liveLog.isNotBlank() -> liveLog
            else -> "${logTimestamp()}\nACTION: LOG CREATED\nBEFORE: ${snapshot()}\nAFTER:  ${snapshot()}\n"
        }

        return header + body
    }

    fun saveLogDirectlyToDownloads(fileName: String, logText: String): String {
        val bytes = logText.toByteArray(Charsets.UTF_8)
        if (bytes.isEmpty()) error("Bug log text is empty before saving")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create Downloads file")

            try {
                resolver.openOutputStream(uri, "w")?.use { stream ->
                    stream.write(bytes)
                    stream.flush()
                } ?: error("Could not open Downloads output stream")

                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                return "Downloads/$fileName (${bytes.size} bytes)"
            } catch (error: Exception) {
                resolver.delete(uri, null, null)
                throw error
            }
        }

        val directory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        if (!directory.exists()) directory.mkdirs()
        val file = File(directory, fileName)
        file.writeBytes(bytes)
        return "${file.absolutePath} (${bytes.size} bytes)"
    }


    fun clampCursor() {
        cursor = cursor.coerceIn(0, expression.length)
    }

    fun updateVariable(name: String, value: Double) {
        variables = variables.toMutableMap().also { it[name] = value }.toMap()
    }

    fun openModeMenu() {
        activeMenu = ActiveMenu.MODE
        status = "MODE: select 1-8"
    }

    fun openSetupMenu() {
        activeMenu = ActiveMenu.SETUP
        status = "SETUP: press 1-9"
    }

    fun setCalcMode(mode: CalcMode) {
        calcMode = mode
        activeMenu = ActiveMenu.NONE
        status = if (mode == CalcMode.STAT) "STAT quick: type mean(...), sx(...), sumx(...)" else "${mode.display}: ${mode.hint}"
    }

    fun formatResult(value: Double): String {
        return CalculatorEngine.format(value, displayMode, engineeringShift)
    }

    fun refreshResultFromCurrentExpression(addHistoryEntry: Boolean = false): Boolean {
        return try {
            val rawExpression = expression
            val value = if (rawExpression.isBlank()) {
                ans
            } else {
                CalculatorEngine.evaluate(rawExpression, angleMode, ans, variables)
            }
            ans = value
            result = formatResult(value)
            if (rawExpression.isNotBlank()) {
                lastEvaluatedRaw = rawExpression
                if (addHistoryEntry) {
                    history = (listOf("${pretty(rawExpression)} = $result") + history).take(3)
                    historyRaw = (listOf(rawExpression) + historyRaw).distinct().take(12)
                }
            }
            true
        } catch (error: Exception) {
            result = error.message ?: "Error"
            status = "Use ◀ ▶ to fix expression"
            false
        }
    }

    fun insert(value: String) {
        clampCursor()

        // After "=", Casio-style behavior:
        // - DEL must not erase the completed calculation.
        // - A digit/function starts a new input.
        // - An operator continues from Ans.
        if (justEvaluated) {
            val continuesFromAns = value in listOf("+", "-", "×", "÷", "^", "%")
            expression = if (continuesFromAns) "ans" else ""
            cursor = expression.length
            justEvaluated = false
        }

        expression = expression.substring(0, cursor) + value + expression.substring(cursor)
        cursor += value.length
        historyIndex = -1
        lastEvaluatedRaw = null
    }

    fun insertTemplate(value: String, cursorBack: Int) {
        clampCursor()
        if (justEvaluated) {
            expression = ""
            cursor = 0
            justEvaluated = false
        }
        expression = expression.substring(0, cursor) + value + expression.substring(cursor)
        cursor += value.length - cursorBack
        historyIndex = -1
        lastEvaluatedRaw = null
    }

    fun insertFunction(name: String) {
        insert("$name(")
    }

    fun fractionNumeratorStart(): Int {
        clampCursor()
        if (cursor == 0) return cursor

        var i = cursor - 1
        if (i < 0) return cursor

        // If the token before the cursor is a closed bracket/function call, wrap the full bracketed expression.
        if (expression[i] == ')') {
            var depth = 0
            var open = -1
            for (j in i downTo 0) {
                when (expression[j]) {
                    ')' -> depth++
                    '(' -> {
                        depth--
                        if (depth == 0) {
                            open = j
                            break
                        }
                    }
                }
            }

            if (open >= 0) {
                var start = open
                while (start > 0 && expression[start - 1].isLetter()) {
                    start--
                }
                return start
            }
        }

        // Otherwise wrap the last visible value only: number, Ans, variable, pi/e.
        while (i >= 0 && (expression[i].isLetterOrDigit() || expression[i] == '.' || expression[i] == 'π')) {
            i--
        }

        return i + 1
    }

    fun insertFractionTemplate() {
        // Casio-like Natural Display behavior:
        // 9 then a/b becomes frac(9,) with the cursor in the denominator.
        // a/b with no value creates frac(,) with the cursor in the numerator.
        clampCursor()
        if (justEvaluated) {
            expression = ""
            cursor = 0
            justEvaluated = false
        }
        val start = fractionNumeratorStart()
        val numerator = expression.substring(start, cursor)

        if (numerator.isBlank()) {
            insertTemplate("frac(,)", cursorBack = 2)
            status = "Fraction: enter numerator, ▼ denominator"
            return
        }

        expression = expression.substring(0, start) +
            "frac($numerator,)" +
            expression.substring(cursor)
        cursor = start + "frac(".length + numerator.length + 1
        historyIndex = -1
        lastEvaluatedRaw = null
        status = "Fraction: $numerator over □"
    }

    fun insertReciprocalTemplate() {
        // Casio-like Natural Display behavior for x⁻¹:
        // blank + x⁻¹ creates □⁻¹ with the cursor in the base slot.
        // 5 + x⁻¹ converts the previous visible value to 5⁻¹.
        clampCursor()
        if (justEvaluated) {
            expression = "ans"
            cursor = expression.length
            justEvaluated = false
        }

        val start = fractionNumeratorStart()
        val base = expression.substring(start, cursor)

        if (base.isBlank()) {
            insertTemplate("pow(,-1)", cursorBack = 4)
            status = "Reciprocal: enter base"
            return
        }

        val template = "pow($base,-1)"
        expression = expression.substring(0, start) +
            template +
            expression.substring(cursor)
        cursor = start + template.length
        historyIndex = -1
        lastEvaluatedRaw = null
        status = "Reciprocal: $base⁻¹"
    }

    fun insertPowerTemplate() {
        // Casio-like Natural Display behavior for xʸ:
        // 5 + xʸ becomes 5^□ with the cursor in the exponent.
        // After a completed result, xʸ continues from Ans as Ans^□.
        clampCursor()
        if (justEvaluated) {
            expression = "ans"
            cursor = expression.length
            justEvaluated = false
        }

        val start = fractionNumeratorStart()
        val base = expression.substring(start, cursor)

        if (base.isBlank()) {
            insertTemplate("pow(,)", cursorBack = 2)
            status = "Power: enter base"
            return
        }

        val template = "pow($base,)"
        expression = expression.substring(0, start) +
            template +
            expression.substring(cursor)
        cursor = start + "pow(".length + base.length + 1
        historyIndex = -1
        lastEvaluatedRaw = null
        status = "Power: ${pretty(base)}^□"
    }

    fun markEdited() {
        historyIndex = -1
        lastEvaluatedRaw = null
        justEvaluated = false
    }

    fun removeDanglingFractionToken() {
        val before = expression.substring(0, cursor.coerceIn(0, expression.length))
        val dangling = listOf("frac", "fra", "fr").firstOrNull { before.endsWith(it) }
        if (dangling != null) {
            expression = expression.removeRange(cursor - dangling.length, cursor)
            cursor -= dangling.length
            status = "Removed incomplete fraction marker"
        }
    }

    fun fractionComma(bounds: TemplateCursorBounds): Int {
        return bounds.argumentStarts.getOrNull(1)?.minus(1) ?: -1
    }

    fun fractionNumerator(bounds: TemplateCursorBounds): String {
        val comma = fractionComma(bounds)
        return if (bounds.functionName == "frac" && comma >= bounds.argsStart) {
            expression.substring(bounds.argsStart, comma)
        } else ""
    }

    fun fractionDenominator(bounds: TemplateCursorBounds): String {
        val comma = fractionComma(bounds)
        return if (bounds.functionName == "frac" && comma >= bounds.argsStart && bounds.end >= comma + 1) {
            expression.substring(comma + 1, bounds.end)
        } else ""
    }

    fun unwrapFraction(bounds: TemplateCursorBounds) {
        val numerator = fractionNumerator(bounds)
        expression = expression.substring(0, bounds.functionStart) +
            numerator +
            expression.substring(bounds.end + 1)
        cursor = bounds.functionStart + numerator.length
        markEdited()
        status = "Fraction removed"
    }

    fun templateLabel(name: String): String {
        return when (name) {
            "integral" -> "Integral"
            "deriv" -> "Derivative"
            "pow" -> "Power"
            "root" -> "Root"
            "logbase" -> "Log template"
            "sum" -> "Summation"
            "prod" -> "Product"
            else -> pretty("$name(").removeSuffix("(")
        }
    }

    fun templateArguments(bounds: TemplateCursorBounds): List<String> {
        val stops = bounds.argumentStarts.drop(1).map { it - 1 } + listOf(bounds.end)
        return bounds.argumentStarts.zip(stops).map { (start, stop) ->
            if (start <= stop && start <= expression.length && stop <= expression.length) {
                expression.substring(start, stop)
            } else {
                ""
            }
        }
    }

    fun templateArgumentIndex(bounds: TemplateCursorBounds): Int {
        val safeCursor = cursor.coerceIn(bounds.argsStart, bounds.end)
        return bounds.argumentStarts.indexOfLast { safeCursor >= it }.coerceAtLeast(0)
    }

    fun removeTemplate(bounds: TemplateCursorBounds) {
        val label = templateLabel(bounds.functionName)
        expression = expression.substring(0, bounds.functionStart) +
            expression.substring(bounds.end + 1)
        cursor = bounds.functionStart.coerceIn(0, expression.length)
        markEdited()
        status = "$label removed"
    }

    fun protectTemplateDelete(bounds: TemplateCursorBounds, deleteForward: Boolean): Boolean {
        if (bounds.functionName == "frac") return false

        val target = if (deleteForward) {
            expression.getOrNull(cursor)
        } else {
            if (cursor > 0) expression.getOrNull(cursor - 1) else null
        }

        // Never allow DEL/backspace to expose hidden raw tokens such as integral, pow, or logbase.
        if (target == null) return false

        val currentArg = templateArguments(bounds).getOrElse(templateArgumentIndex(bounds)) { "" }

        if (deleteForward && cursor in bounds.functionStart until bounds.argsStart) {
            removeTemplate(bounds)
            return true
        }

        if (!deleteForward && cursor in (bounds.functionStart + 1)..bounds.argsStart) {
            removeTemplate(bounds)
            return true
        }

        if (target == ',' || target == '(') {
            if (currentArg.isBlank()) {
                removeTemplate(bounds)
            } else {
                status = "${templateLabel(bounds.functionName)} boundary"
            }
            return true
        }

        if (target == ')') {
            if (currentArg.isBlank()) {
                removeTemplate(bounds)
            } else if (deleteForward) {
                // At the invisible final ')' of a template, DEL should remove the previous visible input,
                // not the hidden ')' that keeps the natural template valid.
                if (cursor > bounds.argsStart) {
                    expression = expression.removeRange(cursor - 1, cursor)
                    cursor--
                    markEdited()
                    status = "${templateLabel(bounds.functionName)} edited"
                } else {
                    removeTemplate(bounds)
                }
            } else {
                status = "${templateLabel(bounds.functionName)} boundary"
            }
            return true
        }

        return false
    }


    fun currentTemplateBounds(): TemplateCursorBounds? {
        val safeCursor = cursor.coerceIn(0, expression.length)
        var best: TemplateCursorBounds? = null

        for (open in expression.indices) {
            if (expression[open] != '(') continue

            var nameStart = open - 1
            while (nameStart >= 0 && expression[nameStart].isLetterOrDigit()) {
                nameStart--
            }
            nameStart++
            if (nameStart >= open) continue

            val name = expression.substring(nameStart, open)
            var depth = 0
            var close = -1
            val commaPositions = mutableListOf<Int>()

            for (i in open + 1 until expression.length) {
                when (expression[i]) {
                    '(' -> depth++
                    ')' -> {
                        if (depth == 0) {
                            close = i
                            break
                        }
                        depth--
                    }
                    ',' -> if (depth == 0) commaPositions.add(i)
                }
            }

            if (close < 0) continue
            if (safeCursor in (open + 1)..close) {
                val starts = listOf(open + 1) + commaPositions.map { it + 1 }
                best = TemplateCursorBounds(nameStart, open + 1, starts, close, name)
            }
        }

        return best
    }

    fun backspace() {
        clampCursor()
        if (justEvaluated) {
            status = "Result locked: press AC to clear or ◀/▶ to edit"
            return
        }

        val bounds = currentTemplateBounds()
        if (bounds != null && bounds.functionName == "frac") {
            val comma = fractionComma(bounds)
            val numerator = fractionNumerator(bounds)
            val denominator = fractionDenominator(bounds)

            // Casio-like protection: never let DEL/backspace expose raw "frac(" text.
            // At the start of an empty denominator, Backspace returns to the numerator.
            if (comma >= 0 && cursor == comma + 1 && denominator.isBlank()) {
                cursor = bounds.argsStart + numerator.length
                status = "Fraction numerator"
                return
            }

            // Empty numerator + backspace removes the whole template.
            if (cursor == bounds.argsStart && numerator.isBlank()) {
                expression = expression.removeRange(bounds.functionStart, bounds.end + 1)
                cursor = bounds.functionStart
                markEdited()
                status = "Fraction removed"
                return
            }

            // If a structural character would be deleted, unwrap instead of corrupting the template.
            if (cursor > bounds.functionStart && expression.getOrNull(cursor - 1) in listOf('(', ',', ')')) {
                unwrapFraction(bounds)
                return
            }
        }

        if (bounds != null && protectTemplateDelete(bounds, deleteForward = false)) {
            return
        }

        if (cursor > 0) {
            expression = expression.removeRange(cursor - 1, cursor)
            cursor--
            markEdited()
            removeDanglingFractionToken()
        }
    }

    fun deleteAtCursor() {
        clampCursor()
        if (justEvaluated) {
            status = "Result locked: press AC to clear or ◀/▶ to edit"
            return
        }

        val bounds = currentTemplateBounds()
        if (bounds != null && bounds.functionName == "frac") {
            val comma = fractionComma(bounds)
            val numerator = fractionNumerator(bounds)
            val denominator = fractionDenominator(bounds)

            // DEL at an empty fraction slot should not delete the hidden ')' and reveal raw frac text.
            if (comma >= 0 && cursor == comma + 1 && denominator.isBlank() && expression.getOrNull(cursor) == ')') {
                status = "Denominator empty"
                return
            }

            if (cursor == bounds.argsStart && numerator.isBlank() && expression.getOrNull(cursor) == ',') {
                status = "Numerator empty"
                return
            }

            if (cursor in bounds.functionStart..bounds.argsStart && expression.getOrNull(cursor) in listOf('f', 'r', 'a', 'c', '(')) {
                unwrapFraction(bounds)
                return
            }
        }

        if (bounds != null && protectTemplateDelete(bounds, deleteForward = true)) {
            return
        }

        if (cursor < expression.length) {
            expression = expression.removeRange(cursor, cursor + 1)
            markEdited()
            removeDanglingFractionToken()
        } else {
            backspace()
        }
    }

    fun moveCursor(delta: Int) {
        justEvaluated = false
        cursor = (cursor + delta).coerceIn(0, expression.length)
        status = "Cursor ${cursor}/${expression.length}"
    }

    fun moveToStart() {
        justEvaluated = false
        cursor = 0
        status = "Cursor start"
    }

    fun moveToEnd() {
        justEvaluated = false
        cursor = expression.length
        status = "Cursor end"
    }

    fun replay(delta: Int) {
        if (historyRaw.isEmpty()) {
            status = "No replay history"
            return
        }
        val next = if (historyIndex < 0) 0 else (historyIndex + delta).coerceIn(0, historyRaw.lastIndex)
        historyIndex = next
        justEvaluated = false
        expression = historyRaw[next]
        cursor = expression.length
        status = "Replay ${next + 1}/${historyRaw.size}"
    }

    fun templateBoundsAtCursor(): TemplateCursorBounds? {
        val safeCursor = cursor.coerceIn(0, expression.length)
        var best: TemplateCursorBounds? = null

        for (open in expression.indices) {
            if (expression[open] != '(') continue

            var nameStart = open - 1
            while (nameStart >= 0 && expression[nameStart].isLetterOrDigit()) {
                nameStart--
            }
            nameStart++
            if (nameStart >= open) continue

            val name = expression.substring(nameStart, open)
            var depth = 0
            var close = -1
            val commaPositions = mutableListOf<Int>()

            for (i in open + 1 until expression.length) {
                when (expression[i]) {
                    '(' -> depth++
                    ')' -> {
                        if (depth == 0) {
                            close = i
                            break
                        }
                        depth--
                    }
                    ',' -> if (depth == 0) commaPositions.add(i)
                }
            }

            if (close < 0) continue
            if (safeCursor in (open + 1)..close) {
                val starts = listOf(open + 1) + commaPositions.map { it + 1 }
                best = TemplateCursorBounds(nameStart, open + 1, starts, close, name)
            }
        }

        return best
    }

    fun argumentIndex(bounds: TemplateCursorBounds): Int {
        val safeCursor = cursor.coerceIn(bounds.argsStart, bounds.end)
        return bounds.argumentStarts.indexOfLast { safeCursor >= it }.coerceAtLeast(0)
    }

    fun upOrReplay() {
        val bounds = templateBoundsAtCursor()
        if (bounds != null && bounds.argumentStarts.isNotEmpty()) {
            val nextIndex = (argumentIndex(bounds) - 1).coerceAtLeast(0)
            justEvaluated = false
            cursor = bounds.argumentStarts[nextIndex]
            status = "${pretty(bounds.functionName)} argument ${nextIndex + 1}"
        } else {
            replay(1)
        }
    }

    fun downOrReplay() {
        val bounds = templateBoundsAtCursor()
        if (bounds != null && bounds.argumentStarts.size > 1) {
            val nextIndex = (argumentIndex(bounds) + 1).coerceAtMost(bounds.argumentStarts.lastIndex)
            justEvaluated = false
            cursor = bounds.argumentStarts[nextIndex]
            status = "${pretty(bounds.functionName)} argument ${nextIndex + 1}"
        } else {
            replay(-1)
        }
    }

    fun rightOrExitTemplate() {
        val bounds = templateBoundsAtCursor()
        if (bounds != null && argumentIndex(bounds) == bounds.argumentStarts.lastIndex) {
            justEvaluated = false
            cursor = (bounds.end + 1).coerceAtMost(expression.length)
            status = "Exited ${pretty(bounds.functionName)}"
        } else {
            moveCursor(1)
        }
    }

    fun cycleAngle() {
        angleMode = when (angleMode) {
            AngleMode.DEG -> AngleMode.RAD
            AngleMode.RAD -> AngleMode.GRAD
            AngleMode.GRAD -> AngleMode.DEG
        }
        status = "Angle mode: ${angleMode.name}"
    }

    fun toggleFractionDecimal() {
        engineeringShift = 0
        displayMode = if (displayMode == DisplayMode.FRACTION) DisplayMode.DECIMAL else DisplayMode.FRACTION
        refreshResultFromCurrentExpression()
        status = "Display: ${displayMode.name}"
    }

    fun toggleEngineering() {
        val hasUnevaluatedExpression = expression.isNotBlank() && expression != lastEvaluatedRaw
        if (hasUnevaluatedExpression) {
            // Casio-like behavior: typing 1000 then ENG should evaluate the current input,
            // not reformat the old Ans value of 0.
            displayMode = DisplayMode.ENGINEERING
            engineeringShift = 0
            if (refreshResultFromCurrentExpression()) {
                status = "ENG: current input"
            }
            return
        }

        if (displayMode == DisplayMode.ENGINEERING) {
            engineeringShift += 1
            refreshResultFromCurrentExpression()
            status = "ENG +3 exponent"
        } else {
            displayMode = DisplayMode.ENGINEERING
            engineeringShift = 0
            refreshResultFromCurrentExpression()
            status = "ENG: value ×10ⁿ"
        }
    }

    fun reverseEngineering() {
        if (displayMode == DisplayMode.ENGINEERING) {
            engineeringShift -= 1
            refreshResultFromCurrentExpression()
            status = "ENG -3 exponent"
        } else {
            moveCursor(-1)
        }
    }

    fun clearAll() {
        // AC must fully clear the visible working state.
        // Keep Ans internally like a real scientific calculator, but never keep
        // the old preview/history/ENG text on the display after AC.
        expression = ""
        cursor = 0
        result = "0"
        engineeringShift = 0
        shift = false
        alpha = false
        hyp = false
        pendingAction = PendingAction.NONE
        activeMenu = ActiveMenu.NONE
        history = emptyList()
        historyRaw = emptyList()
        historyIndex = -1
        lastEvaluatedRaw = null
        justEvaluated = false
        status = "Ready"
    }

    fun evaluate() {
        if (refreshResultFromCurrentExpression(addHistoryEntry = true)) {
            cursor = expression.length
            historyIndex = -1
            justEvaluated = true
            status = "DEL locked"
        }
    }

    fun handleVariable(name: String) {
        when (pendingAction) {
            PendingAction.STORE -> {
                updateVariable(name, ans)
                status = "Stored ${CalculatorEngine.format(ans)} to $name"
                pendingAction = PendingAction.NONE
            }
            PendingAction.RECALL -> {
                insert(name)
                status = "Inserted variable $name"
                pendingAction = PendingAction.NONE
            }
            PendingAction.NONE -> {
                insert(name)
                status = "Variable $name"
            }
        }
    }

    fun handleAlpha(key: CalcKey) {
        val label = key.alpha
        if (label == null) {
            status = "No ALPHA function on ${key.primary}"
            return
        }
        when (label) {
            "π" -> insert("pi")
            "e" -> insert("e")
            "A", "B", "C", "D", "E", "F", "X", "Y", "M" -> handleVariable(label)
            else -> status = "ALPHA $label"
        }
    }

    fun handleShift(label: String) {
        when (label) {
            "OFF" -> clearAll()
            "SETUP" -> openSetupMenu()
            "SOLVE" -> setCalcMode(CalcMode.EQN)
            "d/dx" -> insertTemplate("deriv(,)", cursorBack = 2)
            "x!" -> insert("!")
            "Σ" -> insertTemplate("sum(,,)", cursorBack = 3)
            "d/c", "a⇔b" -> toggleFractionDecimal()
            "³√" -> insertFunction("cbrt")
            "x³" -> insert("^3")
            "ʸ√x" -> insertTemplate("root(,)", cursorBack = 2)
            "10ˣ" -> insertFunction("pow10")
            "eˣ" -> insertFunction("exp")
            "Abs" -> insertFunction("abs")
            "Rnd" -> insertFunction("round")
            "sin⁻¹" -> insertFunction("asin")
            "cos⁻¹" -> insertFunction("acos")
            "tan⁻¹" -> insertFunction("atan")
            "STO" -> {
                pendingAction = PendingAction.STORE
                status = "Press ALPHA then A-F, X, Y, or M"
            }
            "←" -> reverseEngineering()
            "%" -> insert("%")
            "," -> insert(",")
            "M-" -> {
                updateVariable("M", (variables["M"] ?: 0.0) - ans)
                status = "M updated"
            }
            "CONST" -> status = "Constants preview: π, e. Use ALPHA EXP for π and ALPHA Ans for e."
            "CONV" -> status = "CONV preview: full conversion table planned."
            "CLR" -> clearAll()
            "INS" -> status = "Natural Display uses insert-style editing"
            "MATRIX" -> setCalcMode(CalcMode.MATRIX)
            "VECTOR" -> setCalcMode(CalcMode.VECTOR)
            "STAT" -> setCalcMode(CalcMode.STAT)
            "CMPLX" -> setCalcMode(CalcMode.CMPLX)
            "BASE" -> setCalcMode(CalcMode.BASE_N)
            "nPr" -> insertFunction("npr")
            "nCr" -> insertFunction("ncr")
            "Pol" -> insertFunction("polr")
            "Rec" -> insertFunction("recx")
            "Ran#" -> insert("rand()")
            "RanInt" -> insertFunction("randint")
            "π" -> insert("pi")
            "DRG" -> cycleAngle()
            else -> status = "Function $label is planned"
        }
    }

    fun handleMenuKey(label: String): Boolean {
        if (activeMenu == ActiveMenu.NONE) return false

        if (label == "AC" || label == "DEL" || label == "ON") {
            activeMenu = ActiveMenu.NONE
            status = "Menu closed"
            return true
        }

        when (activeMenu) {
            ActiveMenu.MODE -> {
                when (label) {
                    "1" -> setCalcMode(CalcMode.COMP)
                    "2" -> setCalcMode(CalcMode.CMPLX)
                    "3" -> setCalcMode(CalcMode.STAT)
                    "4" -> setCalcMode(CalcMode.BASE_N)
                    "5" -> setCalcMode(CalcMode.EQN)
                    "6" -> setCalcMode(CalcMode.MATRIX)
                    "7" -> setCalcMode(CalcMode.TABLE)
                    "8" -> setCalcMode(CalcMode.VECTOR)
                    else -> status = "MODE: select 1-8"
                }
            }
            ActiveMenu.SETUP -> {
                when (label) {
                    "1" -> {
                        displayMode = DisplayMode.DECIMAL
                        status = "Input/Output: MathIO"
                    }
                    "2" -> {
                        displayMode = DisplayMode.DECIMAL
                        status = "Input/Output: LineIO preview"
                    }
                    "3" -> {
                        angleMode = AngleMode.DEG
                        status = "Angle: DEG"
                    }
                    "4" -> {
                        angleMode = AngleMode.RAD
                        status = "Angle: RAD"
                    }
                    "5" -> {
                        angleMode = AngleMode.GRAD
                        status = "Angle: GRAD"
                    }
                    "6" -> {
                        displayMode = DisplayMode.FRACTION
                        status = "Result: fraction when possible"
                    }
                    "7" -> {
                        displayMode = DisplayMode.SCIENTIFIC
                        status = "Result: scientific"
                    }
                    "8" -> {
                        displayMode = DisplayMode.DECIMAL
                        status = "Result: normal decimal"
                    }
                    "9" -> {
                        displayMode = DisplayMode.ENGINEERING
                        engineeringShift = 0
                        result = formatResult(ans)
                        status = "Result: engineering"
                    }
                    else -> status = "SETUP: press 1-9"
                }
                if (label in listOf("1","2","3","4","5","6","7","8","9")) {
                    activeMenu = ActiveMenu.NONE
                    result = formatResult(ans)
                }
            }
            ActiveMenu.NONE -> Unit
        }
        return true
    }

    fun handlePrimary(label: String) {
        when (label) {
            "AC", "ON" -> clearAll()
            "DEL" -> deleteAtCursor()
            "=" -> evaluate()
            "MODE" -> openModeMenu()
            "CALC" -> evaluate()
            "∫dx" -> {
                insertTemplate("integral(,,)", cursorBack = 3)
                status = "Integral: enter f(x), ▼ lower, ▼ upper"
            }
            "x⁻¹" -> insertReciprocalTemplate()
            "log□" -> insertTemplate("logbase(,)", cursorBack = 2)
            "a/b" -> insertFractionTemplate()
            "√" -> insertFunction("sqrt")
            "x²" -> insert("^2")
            "xʸ" -> insertPowerTemplate()
            "log" -> insertFunction("log")
            "ln" -> insertFunction("ln")
            "(-)" -> insert("-")
            "°′″" -> insertFunction("dms")
            "hyp" -> {
                hyp = !hyp
                status = if (hyp) "HYP enabled for next trig key" else "HYP off"
            }
            "sin", "cos", "tan" -> {
                insertFunction(if (hyp) "${label}h" else label)
                hyp = false
            }
            "RCL" -> {
                pendingAction = PendingAction.RECALL
                status = "Press ALPHA then A-F, X, Y, or M"
            }
            "ENG" -> toggleEngineering()
            "S⇔D" -> toggleFractionDecimal()
            "M+" -> {
                updateVariable("M", (variables["M"] ?: 0.0) + ans)
                status = "M updated"
            }
            "EXP" -> insert("E")
            "Ans" -> insert("ans")
            "×" -> insert("×")
            "÷" -> insert("÷")
            "+", "-", "(", ")", ".", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" -> insert(label)
            else -> status = "$label pressed"
        }
    }

    fun press(key: CalcKey) {
        val before = snapshot()
        var action = key.primary

        try {
            when (key.primary) {
                "SHIFT" -> {
                    action = "SHIFT toggle"
                    shift = !shift
                    alpha = false
                    status = if (shift) "SHIFT" else "Ready"
                    return
                }
                "ALPHA" -> {
                    action = "ALPHA toggle"
                    alpha = !alpha
                    shift = false
                    status = if (alpha) "ALPHA" else "Ready"
                    return
                }
            }

            if (handleMenuKey(key.primary)) {
                action = "MENU ${key.primary}"
                shift = false
                alpha = false
                return
            }

            if (alpha) {
                action = "ALPHA ${key.alpha ?: key.primary}"
                handleAlpha(key)
                alpha = false
                return
            }

            if (shift) {
                val label = key.shift
                action = "SHIFT ${label ?: key.primary}"
                if (label == null) {
                    status = "No SHIFT function on ${key.primary}"
                } else {
                    handleShift(label)
                }
                shift = false
                return
            }

            action = "KEY ${key.primary}"
            handlePrimary(key.primary)
        } finally {
            appendLog(action, before, snapshot())
        }
    }

    val displayExpression = when (activeMenu) {
        ActiveMenu.MODE -> "MODE\n1 COMP       2 CMPLX\n3 STAT       4 BASE-N\n5 EQN        6 MATRIX\n7 TABLE      8 VECTOR"
        ActiveMenu.SETUP -> "SETUP\n1 MathIO     2 LineIO\n3 Deg        4 Rad        5 Gra\n6 Fraction   7 Sci        8 Norm\n9 ENG"
        ActiveMenu.NONE -> if (expression.isBlank()) {
            if (calcMode == CalcMode.STAT) {
                "STAT 1-VAR QUICK\nmean(1,2,3)  sx(1,2,3)\nsigmax(1,2,3)  sumx(1,2,3)"
            } else {
                CursorMark
            }
        } else {
            expression.substring(0, cursor.coerceIn(0, expression.length)) +
                CursorMark +
                expression.substring(cursor.coerceIn(0, expression.length))
        }
    }

    val displayResult = if (activeMenu == ActiveMenu.NONE) result else ""
    val displayStatus = when (activeMenu) {
        ActiveMenu.MODE -> "MODE · press 1-8"
        ActiveMenu.SETUP -> "SETUP · press 1-9"
        ActiveMenu.NONE -> status
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Body
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Header(angleMode, displayMode, calcMode, shift, alpha, hyp)
            DisplayPanel(
                expression = displayExpression,
                result = displayResult,
                history = history,
                status = displayStatus,
                variables = variables,
                calcMode = calcMode,
                logCount = logLines.size,
                onDownloadLog = {
                    val beforeDownload = snapshot()
                    appendLog("DOWNLOAD BUG LOG PRESSED", beforeDownload, snapshot())
                    try {
                        val fileName = "rayd_bug_log_${System.currentTimeMillis()}.txt"
                        val logText = buildLogText()
                        val savedTo = saveLogDirectlyToDownloads(fileName, logText)
                        status = "LOG saved: $savedTo"
                        appendLog("DOWNLOAD BUG LOG SAVED", beforeDownload, snapshot())
                        Toast.makeText(context, "LOG saved to $savedTo", Toast.LENGTH_LONG).show()
                    } catch (error: Exception) {
                        status = "LOG save failed: ${error.message}"
                        appendLog("DOWNLOAD BUG LOG FAILED", beforeDownload, snapshot())
                        Toast.makeText(context, status, Toast.LENGTH_LONG).show()
                    }
                }
            )
            ReplayPad(
                onLeft = { runLogged("NAV LEFT") { moveCursor(-1) } },
                onRight = { runLogged("NAV RIGHT / EXIT TEMPLATE") { rightOrExitTemplate() } },
                onUp = { runLogged("NAV UP / REPLAY") { upOrReplay() } },
                onDown = { runLogged("NAV DOWN / REPLAY") { downOrReplay() } },
                onCenter = { runLogged("CENTER / CALC") { evaluate() } }
            )
            Keypad(
                onKey = ::press,
                shiftActive = shift,
                alphaActive = alpha,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun Header(
    angleMode: AngleMode,
    displayMode: DisplayMode,
    calcMode: CalcMode,
    shift: Boolean,
    alpha: Boolean,
    hyp: Boolean
) {
    // Top branding intentionally shows only the new model name.
    // Extra brand/model/status text was removed as requested.
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(20.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "RAYDSC",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 24.sp,
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun DisplayPanel(
    expression: String,
    result: String,
    history: List<String>,
    status: String,
    variables: Map<String, Double>,
    calcMode: CalcMode,
    logCount: Int,
    onDownloadLog: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Display),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 140.dp)
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                NaturalExpression(
                    raw = expression,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))

                history.take(2).forEach {
                    Text(
                        text = it,
                        color = Color(0xFF4C5B51),
                        fontSize = 10.sp,
                        maxLines = 1,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) {
                NaturalResult(
                    result = result,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${calcMode.display} · $status   M=${CalculatorEngine.format(variables["M"] ?: 0.0)}",
                        color = Color(0xFF526053),
                        fontSize = 10.sp,
                        maxLines = 1,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = onDownloadLog,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF526053),
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text(text = "LOG $logCount", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReplayPad(
    onLeft: () -> Unit,
    onRight: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onCenter: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(18.dp))
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavButton("◀", "left", Modifier.weight(1f), onLeft)
        Column(
            modifier = Modifier.weight(1.2f),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NavButton("▲", "num", Modifier.fillMaxWidth(), onUp)
            NavButton("", "", Modifier.fillMaxWidth(), onCenter)
            NavButton("▼", "den", Modifier.fillMaxWidth(), onDown)
        }
        NavButton("▶", "exit", Modifier.weight(1f), onRight)
    }
}

@Composable
private fun NavButton(
    label: String,
    hint: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        modifier = modifier.height(40.dp),
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = FunctionKey,
            contentColor = Color.White
        ),
        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 1.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = label, fontSize = if (label.isBlank()) 1.sp else 17.sp, fontWeight = FontWeight.Bold)
            Text(text = hint, fontSize = 7.sp, color = SecondaryText, maxLines = 1)
        }
    }
}

@Composable
private fun Keypad(
    onKey: (CalcKey) -> Unit,
    shiftActive: Boolean,
    alphaActive: Boolean,
    modifier: Modifier = Modifier
) {
    val scroll = rememberScrollState()
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(scroll),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        keypadRows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                row.forEach { key ->
                    CalcButton(
                        spec = key,
                        shiftActive = shiftActive,
                        alphaActive = alphaActive,
                        modifier = Modifier.weight(1f),
                        onClick = { onKey(key) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CalcButton(
    spec: CalcKey,
    shiftActive: Boolean,
    alphaActive: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val label = spec.primary
    val container = when (label) {
        "AC" -> ActionKey
        "DEL" -> DeleteKey
        "=" -> EqualKey
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "." -> NumberKey
        else -> FunctionKey
    }

    val primaryColor = when (label) {
        "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "." -> NumberText
        "SHIFT" -> ShiftText
        "ALPHA" -> AlphaText
        else -> Color.White
    }

    val outline = when {
        label == "SHIFT" && shiftActive -> ShiftText
        label == "ALPHA" && alphaActive -> AlphaText
        else -> Color(0x33111111)
    }

    Button(
        modifier = modifier.height(47.dp),
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, outline),
        colors = ButtonDefaults.buttonColors(
            containerColor = container,
            contentColor = primaryColor
        ),
        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = spec.shift ?: "",
                    color = ShiftText,
                    fontSize = 8.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = spec.alpha ?: "",
                    color = AlphaText,
                    fontSize = 8.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
            }
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = label,
                    color = primaryColor,
                    fontSize = when {
                        label.length >= 6 -> 10.sp
                        label.length >= 4 -> 12.sp
                        else -> 16.sp
                    },
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun NaturalExpression(raw: String, modifier: Modifier = Modifier) {
    val cleaned = cleanNaturalDisplay(raw)

    val integral = splitFirstTemplate(cleaned, "integral", 3)
    if (integral != null) {
        Row(
            modifier = modifier,
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (integral.prefix.isNotBlank()) {
                Text(
                    text = pretty(integral.prefix),
                    color = DisplayText,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                )
            }
            IntegralView(
                integrand = integral.args.getOrElse(0) { "" },
                lower = integral.args.getOrElse(1) { "" },
                upper = integral.args.getOrElse(2) { "" }
            )
            if (integral.suffix.isNotBlank()) {
                Text(
                    text = pretty(integral.suffix),
                    color = DisplayText,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                )
            }
        }
        return
    }

    val power = splitFirstTemplate(cleaned, "pow", 2)
    if (power != null) {
        Row(
            modifier = modifier,
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (power.prefix.isNotBlank()) {
                Text(
                    text = pretty(power.prefix),
                    color = DisplayText,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                )
            }
            PowerView(
                base = power.args.getOrElse(0) { "" },
                exponent = power.args.getOrElse(1) { "" }
            )
            if (power.suffix.isNotBlank()) {
                Text(
                    text = pretty(power.suffix),
                    color = DisplayText,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                )
            }
        }
        return
    }

    val parts = splitFirstFraction(cleaned)
    if (parts == null) {
        Text(
            text = pretty(cleaned.ifBlank { "0" }),
            color = DisplayText,
            fontFamily = FontFamily.Monospace,
            fontSize = 18.sp,
            lineHeight = 22.sp,
            maxLines = 4,
            textAlign = TextAlign.Start,
            modifier = modifier
        )
    } else {
        Row(
            modifier = modifier,
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (parts.prefix.isNotBlank()) {
                Text(
                    text = pretty(parts.prefix),
                    color = DisplayText,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                )
            }
            FractionView(parts.numerator, parts.denominator)
            if (parts.suffix.isNotBlank()) {
                Text(
                    text = pretty(parts.suffix),
                    color = DisplayText,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 18.sp
                )
            }
        }
    }
}

@Composable
private fun NaturalResult(result: String, modifier: Modifier = Modifier) {
    if (result.isBlank()) {
        Spacer(modifier = modifier.height(1.dp))
        return
    }
    val parts = result.split("/")
    if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank() && !result.contains("E")) {
        Row(
            modifier = modifier,
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FractionView(parts[0], parts[1], large = true)
        }
    } else {
        Text(
            text = result,
            color = DisplayText,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 25.sp,
            maxLines = 1,
            textAlign = TextAlign.End,
            modifier = modifier
        )
    }
}

@Composable
private fun FractionView(
    numerator: String,
    denominator: String,
    large: Boolean = false
) {
    val fontSize = if (large) 22.sp else 17.sp
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .padding(horizontal = 3.dp)
            .width(if (large) 70.dp else 54.dp)
    ) {
        Text(
            text = pretty(numerator).ifBlank { "□" },
            color = DisplayText,
            fontFamily = FontFamily.Monospace,
            fontSize = fontSize,
            maxLines = 1
        )
        Divider(
            color = DisplayText,
            thickness = 1.dp,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            text = pretty(denominator).ifBlank { "□" },
            color = DisplayText,
            fontFamily = FontFamily.Monospace,
            fontSize = fontSize,
            maxLines = 1
        )
    }
}

@Composable
private fun IntegralView(
    integrand: String,
    lower: String,
    upper: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 3.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(46.dp)
        ) {
            Text(
                text = pretty(upper).ifBlank { "□" },
                color = DisplayText,
                fontFamily = FontFamily.Monospace,
                fontSize = 16.sp,
                maxLines = 1
            )
            Text(
                text = "∫",
                color = DisplayText,
                fontFamily = FontFamily.Monospace,
                fontSize = 46.sp,
                lineHeight = 44.sp,
                maxLines = 1
            )
            Text(
                text = pretty(lower).ifBlank { "□" },
                color = DisplayText,
                fontFamily = FontFamily.Monospace,
                fontSize = 16.sp,
                maxLines = 1
            )
        }
        Text(
            text = pretty(integrand).ifBlank { "□" } + "dx",
            color = DisplayText,
            fontFamily = FontFamily.Monospace,
            fontSize = 22.sp,
            maxLines = 1,
            modifier = Modifier.padding(start = 4.dp)
        )
    }
}

@Composable
private fun PowerView(
    base: String,
    exponent: String
) {
    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier.padding(horizontal = 3.dp)
    ) {
        Text(
            text = pretty(base).ifBlank { "□" },
            color = DisplayText,
            fontFamily = FontFamily.Monospace,
            fontSize = 24.sp,
            lineHeight = 26.sp,
            maxLines = 1
        )
        Text(
            text = exponentForDisplay(exponent).ifBlank { "□" },
            color = DisplayText,
            fontFamily = FontFamily.Monospace,
            fontSize = 15.sp,
            maxLines = 1,
            modifier = Modifier.padding(start = 1.dp, top = 0.dp)
        )
    }
}

private data class TemplateParts(
    val prefix: String,
    val args: List<String>,
    val suffix: String
)

private data class FractionParts(
    val prefix: String,
    val numerator: String,
    val denominator: String,
    val suffix: String
)

private data class FractionCursorBounds(
    val numeratorStart: Int,
    val comma: Int,
    val end: Int
)

private fun cleanNaturalDisplay(input: String): String {
    // UI safety: malformed hidden template fragments should never be visible as raw text.
    // This protects against old states such as "...+fra│" after DEL/backspace.
    return input
        .replace("frac$CursorMark", CursorMark)
        .replace("fra$CursorMark", CursorMark)
        .replace("fr$CursorMark", CursorMark)
        .replace(Regex("frac\\z"), "")
        .replace(Regex("fra\\z"), "")
        .replace(Regex("fr\\z"), "")
}

private fun splitFirstTemplate(text: String, functionName: String, expectedArgs: Int): TemplateParts? {
    val marker = "$functionName("
    val start = text.indexOf(marker)
    if (start < 0) return null

    val argsStart = start + marker.length
    var depth = 0
    var end = -1
    val commas = mutableListOf<Int>()

    for (i in argsStart until text.length) {
        when (text[i]) {
            '(' -> depth++
            ')' -> {
                if (depth == 0) {
                    end = i
                    break
                }
                depth--
            }
            ',' -> if (depth == 0) commas.add(i)
        }
    }

    if (end < 0) return null

    val starts = listOf(argsStart) + commas.map { it + 1 }
    val stops = commas + listOf(end)
    val args = starts.zip(stops).map { (s, e) ->
        if (s <= e) text.substring(s, e) else ""
    }.toMutableList()

    while (args.size < expectedArgs) args.add("")
    if (args.size > expectedArgs) return null

    return TemplateParts(
        prefix = text.substring(0, start),
        args = args,
        suffix = text.substring(end + 1)
    )
}

private fun splitFirstFraction(text: String): FractionParts? {
    val start = text.indexOf("frac(")
    if (start < 0) return null

    val argsStart = start + "frac(".length
    var depth = 0
    var comma = -1
    var end = -1

    for (i in argsStart until text.length) {
        when (text[i]) {
            '(' -> depth++
            ')' -> {
                if (depth == 0) {
                    end = i
                    break
                }
                depth--
            }
            ',' -> if (depth == 0 && comma < 0) comma = i
        }
    }

    if (comma < 0 || end < 0) return null

    return FractionParts(
        prefix = text.substring(0, start),
        numerator = text.substring(argsStart, comma),
        denominator = text.substring(comma + 1, end),
        suffix = text.substring(end + 1)
    )
}

private fun defaultVariables(): Map<String, Double> {
    return mapOf(
        "A" to 0.0,
        "B" to 0.0,
        "C" to 0.0,
        "D" to 0.0,
        "E" to 0.0,
        "F" to 0.0,
        "X" to 0.0,
        "Y" to 0.0,
        "M" to 0.0
    )
}

private fun exponentForDisplay(input: String): String {
    val text = pretty(input)
    if (text == CursorMark) return CursorMark
    if (text.isBlank()) return ""
    val map = mapOf(
        '-' to '⁻',
        '0' to '⁰',
        '1' to '¹',
        '2' to '²',
        '3' to '³',
        '4' to '⁴',
        '5' to '⁵',
        '6' to '⁶',
        '7' to '⁷',
        '8' to '⁸',
        '9' to '⁹',
        '+' to '⁺'
    )
    return text.map { map[it] ?: it }.joinToString("")
}

private fun pretty(input: String): String {
    return input
        .replace("frac(", "(")
        .replace("integral(", "∫(")
        .replace("deriv(", "d/dx(")
        .replace("sum(", "Σ(")
        .replace("prod(", "Π(")
        .replace("sqrt(", "√(")
        .replace("cbrt(", "³√(")
        .replace("pow10(", "10^(")
        .replace("exp(", "e^(")
        .replace("asin(", "sin⁻¹(")
        .replace("acos(", "cos⁻¹(")
        .replace("atan(", "tan⁻¹(")
        .replace("logbase(", "log□(")
        .replace("pow(", "^(")
        .replace("sigmax(", "σx(")
        .replace("sumx2(", "Σx²(")
        .replace("sumx(", "Σx(")
        .replace("mean(", "x̄(")
        .replace("sx(", "sx(")
        .replace("root(", "ʸ√(")
        .replace("pi", "π")
        .replace("*", "×")
        .replace("/", "÷")
        .replace("ans", "Ans")
}
