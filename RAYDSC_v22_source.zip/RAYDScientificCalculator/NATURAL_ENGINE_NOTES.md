# RAYD V16 Natural Engine Notes

This file turns the uploaded research notes into an implementation checklist for RAYD.

## Do not use a normal text box as the calculator engine

The calculator should not rely on raw display strings like:

```text
frac(1,2)
sin(30)
```

The correct approach is:

```text
Button → Token → Cursor-aware buffer → MathNode tree → Natural Display renderer → Evaluator
```

## Next engineering tasks

- Build `Token.kt`
- Build `MathNode.kt`
- Build `ExpressionBuffer.kt`
- Build `NaturalLayoutRenderer.kt`
- Build `ResultValue.kt`
- Move DEL/AC/fraction/ENG behavior into these structures
