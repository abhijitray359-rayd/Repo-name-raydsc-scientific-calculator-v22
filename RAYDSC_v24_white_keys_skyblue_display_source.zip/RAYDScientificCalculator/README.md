# RAYDSC V23

V23 updates the visual style and removes the visible OK label.

## V23 changes

- Removed visible `OK` text from the center replay/navigation button.
- Changed the display panel background to pure white.
- Changed calculator body/panel/key style to dark black.
- Changed result/input text on the display to black for readability.
- Changed completed-result status from `OK: DEL locked` to `DEL locked`.
- Keeps V21 template delete, power, and bug-log fixes.

## Build

Upload `RAYDScientificCalculator_v23_source.zip` to GitHub and run `.github/workflows/build-rayd.yml`.

# RAYD Scientific Calculator V21

V21 fixes bugs found from the first successful non-empty bug log.

## V21 changes

- LOG export confirmed working with real action/reaction entries.
- DEL no longer breaks integral templates into raw text like `integral`, `integ`, `in`.
- Empty natural templates are protected from structural comma/parenthesis deletion.
- `xʸ` now wraps the previous value as the base: `5 xʸ` becomes `5^□`.
- After `=`, pressing `xʸ` continues from `Ans` as `Ans^□`.
- DEL at the hidden end of a power template removes the previous visible input, not the hidden `)`.

## Build

Upload `RAYDScientificCalculator_v21_source.zip` to GitHub and run `.github/workflows/build-rayd.yml`.
# RAYD Scientific Calculator V20

V20 fixes the bug log export problem where Android could create a `.txt` file with 0 bytes.

## V20 changes

- Persistent action memory log saved inside app storage after every key/action.
- LOG button exports the saved memory log, not only temporary Compose state.
- Export write is checked; it no longer silently creates an empty file.
- Export toast shows saved character count.
- Keeps V18 changes: removed start/end buttons and keeps the LOG download button.

# RAYD Scientific Calculator V18

Fast-open RAYD scientific calculator with bug-report logging.

## V18 changes

- Removed visible start/end replay buttons.
- Added in-app `LOG` download button.
- Log file records each key/action with before/after state.
- Log can be saved as `rayd_bug_log_*.txt` and sent for bug reports.

# RAYD Scientific Calculator V17

RAYD V17 is a fast-start build based on the V16 Natural Engine baseline.

## What V17 focuses on

- Faster perceived app opening.
- Dark startup window background so the app does not flash a blank/white screen.
- Cached Compose color scheme instead of recreating it at launch.
- Hardware acceleration enabled in manifest.
- Version bumped to V17 while keeping V16 Natural Engine behavior:
  - AC clears stale result/ENG preview.
  - DEL is locked after `=` / OK.
  - `9 → a/b` creates a fraction with `9` as numerator.
  - ENG uses `×10³` superscript style.
  - MODE menu shows COMP, CMPLX, STAT, BASE-N, EQN, MATRIX, TABLE, VECTOR.

## Important note

V16 is a safer rebuild baseline. It does not claim all advanced modes are complete yet.
Full CMPLX, EQN, STAT editor, MATRIX, VECTOR, and TABLE screens should be implemented in later versions.

## GitHub phone build

Upload only:

`RAYDScientificCalculator_v17_source.zip`

Create:

`.github/workflows/build-rayd.yml`

Run:

`Actions → Build RAYD APK → Run workflow`

Artifact:

`rayd-debug-apk`


## V20 Direct Downloads Log Fix

LOG now writes directly to Android Downloads using MediaStore on Android 10+ and an app Downloads folder fallback on older Android. It avoids the previous Create Document picker that could create a 0 byte file on some phones.
